<!-- stream-to-shorts by Akshat96af. Copyright (c) 2026 Akshat96af. All rights reserved. See LICENSE. -->
# stream-to-shorts (web edition)⁠​‌​​​​​‌​‌‌​‌​‌‌​‌‌‌​​‌‌​‌‌​‌​​​​‌‌​​​​‌​‌‌‌​‌​​​​‌‌‌​​‌​​‌‌​‌‌​​‌‌​​​​‌​‌‌​​‌‌​⁠

**By Akshat96af.** The no-install edition of stream-to-shorts for chat assistants such as claude.ai.

Paste a transcript, subtitle file, chat log or a list of timestamps and get a ready clip plan: exact cut points,
a frame-1 hook, cleaned captions, layout, title, description, hashtags and copy-paste cut commands, chosen with the
same rules and lessons as the full desktop edition.

- **Install**: zip this folder (or use the released `.skill` file) and upload it in your assistant's skill settings.
- **Use**: "Plan 5 Shorts from this transcript of my stream" and attach the file.
- **Want automatic rendering** (captions, music, effects, QC, optional upload)? Use the desktop edition.

Copyright (c) 2026 Akshat96af. All rights reserved. Free for your own videos; no resale, re-upload, rebranding or
modified copies. See [LICENSE](LICENSE).
